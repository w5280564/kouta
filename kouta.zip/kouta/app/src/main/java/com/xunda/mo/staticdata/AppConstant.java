package com.xunda.mo.staticdata;

public class AppConstant {
//    public static String endPoint = "obs.cn-east-3.myhuaweicloud.com";
//    public static String ak = "IP3GPV0JTU2VPFT8MCQ7";
//    public static String sk = "3qDRxizVN8ukaMfPPpqtvprzr34TEx7BpwhM1jhC";
//    public static String bucketName = "ahxd-private";
    public static String endPoint = "obs.cn-east-3.myhuaweicloud.com";
    public static String ak = "WXP4NE12LM1DR71LVVPG";
    public static String sk = "kyhbRxXISbVPtsJScwNirHZc6eC3w6nj92ihZoms";
    public static String bucketName = "ahxd-test";
//    public static String bucketName = "ahxd-private-prod";
}
