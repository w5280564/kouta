package com.xunda.mo.hx.common.utils;

import com.hyphenate.util.EMLog;

/**
 * log工具类
 */
public class DemoLog extends EMLog {

}
