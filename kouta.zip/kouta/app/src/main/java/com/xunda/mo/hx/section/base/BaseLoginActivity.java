package com.xunda.mo.hx.section.base;

public abstract class BaseLoginActivity extends BaseInitActivity {

}
