package com.xunda.mo.hx.section.contact.model;

import com.hyphenate.easeui.modules.contact.model.EaseContactCustomBean;

public class MyEaseContactCustomBean extends EaseContactCustomBean {
    private int count;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}

