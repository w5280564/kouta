package com.xunda.mo.hx.common.enums;

public enum Status {
    SUCCESS,
    ERROR,
    LOADING
}
