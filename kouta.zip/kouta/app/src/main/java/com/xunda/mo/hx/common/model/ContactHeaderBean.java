package com.xunda.mo.hx.common.model;

public class ContactHeaderBean {
    private int name;
    private int image;

    public int getName() {
        return name;
    }

    public void setName(int name) {
        this.name = name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}

